import os
from flask import Flask, render_template, request, redirect, jsonify, json

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False

@app.route('/')
@app.route('/index')
def index():
	return render_template('index.html')

@app.route('/register', methods=['GET','POST'])
def register():
	return render_template('register.html')
	
	"""
	if request.method == 'GET':
		return render_template("register.html")
	else:
		username = request.form.get('userid')
		email = request.form.get('email')
		password = request.form.get('password')
		password_re = request.form.get('password')

		if (username & email & password & password_re) is None:
			return "입력되지 않은 정보가 있습니다."
		elif password != password_re:
			return "비밀번호가 일치하지 않습니다."
		else:
			user_data = User()
			user_data.username = username
			user_data.email = email
			user_data.password = password

			db.session.add(user_data)
			db.session.commit()
			return "가입에 성공했습니다.

	return redirect('/')
"""
@app.route('/find')
def find():	
	return render_template('find.html')

@app.route('/input')
def introduce():
	return render_template('input.html')

@app.route('/test')
def test():
	app.config['JSONIFY_PRETTYPRINT_REGULAR'] = True
	with open('flask_app/static/firstdata.json', 'r', encoding='utf-8') as json_file:
		json_data = json.load(json_file)
	return jsonify(json_data)


"""
basdir = os.path.abspath(os.path.dirname(__file__))
dbfile = os.path.join(basdir, 'db.sqlite')

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + dbfile
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'jqiowejrojzxcovnklqnweiorjqwoijroi'

db.init_app(app)
db.app = app
db.create_all()

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
"""
"""
@app.route('/server_info')
def server_inf0():
    data = {'host': '127.0.0.1', 'port': '8080'}
    return jsonify(data)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port="8080")
"""